# CreatorHub — runnable MVP

A zero-dependency Node.js MVP for the product we discussed: creator storefronts + creator-trained AI chat + free-tier ads + paid Pro plan to remove ads.

## Run
Requires Node 20+.

```bash
cp .env.example .env
node server.js
```
Then open http://localhost:3000.

No npm install is required.

## MVP features
- Creator signup/login with salted password hashing
- Public storefronts `/c/<slug>`
- Product management
- Free plan with ad slots
- Pro plan with ads hidden
- AI storefront assistant through OpenAI Responses API
- Creator AI knowledge/context
- Stripe recurring Checkout integration
- Stripe webhook endpoint
- JSON persistence (`data.json`) for the prototype

## Environment
Set these in `.env` when ready:
- `OPENAI_API_KEY`
- `OPENAI_MODEL` (default `gpt-6-luna`)
- `STRIPE_SECRET_KEY`
- `STRIPE_PRICE_ID` (recurring Price)
- `STRIPE_WEBHOOK_SECRET`
- `APP_URL`

The success route marks a user Pro for local MVP testing; production should rely exclusively on verified Stripe webhook events.

## Next production layer
Replace JSON persistence with Postgres, add Stripe Connect for creator payouts, secure file storage, courses/memberships, email automation, proper subscription lifecycle handling, rate limits, CSRF protections, moderation, ad-provider integration, AI usage metering, and a full admin console.
